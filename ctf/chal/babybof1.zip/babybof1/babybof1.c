#include <stdio.h>
#include <stdlib.h>

void win() {
	system("/bin/cat flag.txt");
	exit(0);
}

void vuln() {
	char buf[24];
	puts("Enter the API token: ");
	gets(buf);
	printf("Error code %x\n", __builtin_return_address(0));
}

int main() {
	setbuf(stdout, 0);
	setbuf(stdin, 0);
	setbuf(stderr, 0);
	vuln();
	return 0;
}
