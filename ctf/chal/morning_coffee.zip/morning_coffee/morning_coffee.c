#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void win(void)
{
    system("/bin/bash");
    return;
}


int main(void)
{
    size_t size;
    void *buf;
    void *chunk;
    
    setvbuf(_stdin, 0, 2, 0);
    setvbuf(_stdout, 0, 2, 0);
    puts("Nothing like some coffee in the morning");
    
    // Reserva un gran bloque de memoria en el heap
    chunk = malloc(0xcafe00); // 13303296
    // Inicializa el primer byte
    chunk = 0xff;

    // Usa address fija como cadena de formato -> peligroso (vuln. format string)
    printf(chunk);

    // Pide al usuario el size de su mensaje
    printf("What is the size of your daily message? ");
    scanf("%llu", &size);
    
    // Reserva memoria segun el size dado por el usuario
    user_buffer = malloc(size);
    
    // Lee el mensaje sin comprobación de limites
    printf("Please present your daily message: ");
    read(0, user_buffer, size);
    
    // Aqui esta el overflow: escribe fuera del bufer
    *((char *)user_buffer + size) = 0;

    // Si el primer byte de chunk es cero, ejecuta win()
    if (chunk == '\0') {
        win();
    }
    return 0;
}
