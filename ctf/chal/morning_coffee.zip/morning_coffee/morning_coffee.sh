#!/bin/bash

cd /morning_coffee && ./morning_coffee
