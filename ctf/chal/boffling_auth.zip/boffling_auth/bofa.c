#include <stdio.h>
#include <stdlib.h>

void vuln() {
    struct {
		char buf[48];
		volatile int isAuthenticated;
    } locals;
    locals.isAuthenticated = 0;

	puts("Enter the access code: ");
	gets(locals.buf);
	puts("TODO: Implement access code checking.");

	if(locals.isAuthenticated == 0xdeadbeef) {
		system("/bin/cat flag.txt");
	}
	else {
		puts("Invalid auth!");
	}
}

int main() {
	setbuf(stdout, 0);
	setbuf(stdin, 0);
	setbuf(stderr, 0);
	vuln();
	return 0;
}
