#include <stdio.h>
#include <stdlib.h>


void vuln() {
	char buf[48];
	puts("Enter the API token: ");
	gets(buf);
	puts("Your input has been received.");
}

int main() {
	setbuf(stdout, 0);
	setbuf(stdin, 0);
	setbuf(stderr, 0);
	vuln();
	return 0;
}
