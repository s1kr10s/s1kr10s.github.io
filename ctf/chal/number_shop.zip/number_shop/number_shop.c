#include <stdio.h>
#include <stdlib.h>

// Variable global que representa el dinero del usuario
int money = 100;

// Array que representa la cantidad disponible de cada tipo de número
// [int, size_t, short]
int item_counts[] = { 50, 50, 50 };

// Desactiva el buffer de stdout, stdin y stderr para que la salida sea inmediata
void init() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void menu() {
    puts("Welcome to the Number Shop. How can we help you today?");
    puts("1. Buy a number");
    puts("2. Buy a flag");
    puts("3. Leave");
    printf("> ");
}

void buy_number() {
    int choice; // tipo de numero
    int qty;    // cantidad a comprar

    // Costos fijos iniciales para cada tipo
    int int_cost = 13;
    size_t size_t_cost = 3;
    short short_cost = 37;

    puts("1. Buy an int");
    puts("2. Buy a size_t");
    puts("3. Buy a short");
    printf("Choice> ");

    //valida que el numero sea dentro del rango del menu
    if(scanf("%d", &choice) != 1 || !(1 <= choice && choice <= 3)) {
        puts("We don't sell that here!");
        return;
    }

    // Verifica si hay stock del item seleccionado
    if(item_counts[choice - 1] <= 0) {
        puts("We're out of stock of that item!");
        return;
    }

    // Solicita la cantidad a comprar
    printf("How many would you like?> ");
    if(scanf("%d", &qty) != 1 || qty < 0) {
        puts("That's not a valid quantity!");
        return;
    }

    int can_afford;
    int subtotal;

    // Aquí está la vulnerabilidad:
    // int_cost se modifica antes de comparar con el dinero
    // Si int_cost * qty causa overflow, el resultado será negativo
    if(choice == 1) {
        subtotal = int_cost * qty;      // subtotal: 13*165960281 = -2137483643 <- 0x80989685
        int_cost *= qty;                // int_cost: 13*165960281 = -2137483643 <- 0x80989685
        int_cost -= money;              // int_cost: -2137483643-100 = -2137483743 <- 0x80989621
        can_afford = (int_cost <= 0);   // como int_cost es negativo es menor a 0
    } else if(choice == 2) {
        subtotal = size_t_cost * qty;
        size_t_cost *= qty;
        size_t_cost -= money;
        can_afford = (size_t_cost <= 0);
    } else if(choice == 3) {
        subtotal = short_cost * qty;
        short_cost *= qty;
        short_cost -= money;
        can_afford = (short_cost <= 0);
    }

    if(!can_afford) {
        puts("You do not have enough money to buy that...");
        return;
    } 

    // Compra realizada: se reduce el inventario y el dinero
    item_counts[choice - 1] -= qty;
    money -= subtotal; // 100-(-2137483643) = 2137483743 Aquí ocurre el aumento si subtotal es negativo
    printf("Thank you for your purchase! Your remaining balance is %d\n", money);
}

void buy_flag() {
    if(money > 1337) { // 2137483743 > 1337
        system("cat flag.txt");
    } else {
        puts("You do not have enough money to buy that...");
    }
}

int main () {
    init();

    int choice;

    while(1) {
        menu();
        if(scanf("%d", &choice) != 1) {
            break;
        }
        if(choice == 1) {
            buy_number();
        } else if(choice == 2) {
            buy_flag();
        } else if(choice == 3) {
            break;
        }
    }
}
