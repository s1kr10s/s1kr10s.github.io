#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

void handler(int sig) {
	exit(-2);
}

char code[1000];

int main() {
	setbuf(stdin, 0);
	setbuf(stdout, 0);

	puts("Welcome to our executor! Enter your code below: ");
	signal(SIGALRM, handler);
	alarm(60);

	memset(&code, 0x90, 1000);
	read(0, &code, 1000);

	puts("Processing code...");

	(*(void(*)()) code)();

	return 0;
}
