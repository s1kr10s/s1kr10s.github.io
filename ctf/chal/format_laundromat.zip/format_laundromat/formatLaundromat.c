// Compiled with `gcc -g -no-pie formatLaundromat.c -o formatLaundromat`
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define BUFF_SIZE 1024

int secret = 0xcafebabe;

void print_menu() {
  puts("");
  printf("Please select an action:\n");
  puts("1. Pay");
  puts("2. Start Washer");
  puts("3. Start Dryer");
  puts("4. Leave");
  puts("");
}

void print_banner() {
  printf("==============================\n");
  printf("*** Format Laundromat! ***\n");
  printf("==============================\n");
}

void start_washer() {

  printf(
      "* One day... one day you will have your very own washer and dryer.\n");
  printf("* No longer will you be extorted for the privilege of clean "
         "clothing!\n");
  printf("* One day, you will be able to separate your colors and avoid the "
         "dreaded color bleed!\n");
  printf(
      "* If only there was a way to break out of this clothing rat race...\n");

  if (secret == 0xbaadf00d) {
    printf("* Today is your lucky day! You have finally broken out of the "
           "simualtion.\n");
    system("cat ./flag.txt");
  }
  puts("");
}

void start_dryer() {
  printf("* You insert your hard earned quarters in the ominous looking "
         "machine...\n");
  printf(
      "* As you load your clothing, you wonder if your socks are going to be "
      "sacrificed for the greater good or lost forever into the abyss.\n");
  printf(
      "* None of that matters now as you close the door, and press START...\n");
  puts("");
}

void pay() {

  char feedback[BUFF_SIZE];
  int coins = 0;
  char option = 'N';

  printf("How many coins are you using today: ");
  scanf(" %d", &coins);

  printf("Thank you for your generous contribution!\n");

  printf("Would you like to leave us some feedback? (y/N): ");
  scanf(" %c", &option);

  // Leave feedback
  if (option == 'n' || option == 'N') {
    printf("Thank you for using the Format Laundromat!\n");
    printf("Enjoy doing your laundry!\n");
    return;
  }

  printf("Feedback: ");
  scanf(" %[^\n]", feedback);

  puts("");
  printf("Your feedback is much appreciated.\n");
  printf("For accuracy and customer satisfaction, please confirm your feedback "
         "is correct:\n");
  printf("If it is not, we can't do anything right now because our customer "
         "support center no longer exists!\n");

  printf("============= Your Feedback =============\n");
  printf(feedback);
  puts("");
}

void setup() {
  setbuf(stdout, NULL);
  setbuf(stdin, NULL);
  setbuf(stderr, NULL);
}

int main(int argc, char **argv) {

  setup();

  int action = 0;
  int quit = 1;

  do {
    print_menu();
    scanf(" %d", &action);

    switch (action) {
    case 1:
      pay();
      break;
    case 2:
      start_washer();
      break;
    case 3:
      start_dryer();
      break;
    case 4:
      quit = 0;
      break;
    default:
      printf("Unknown action! Please try again.\n");
      action = 0;
      break;
    }

  } while (quit != 0);

  printf("Thank you for using the Format Laundromat!\n");

  return 0;
}
