#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

void win(int sig) {
	system("/bin/cat flag.txt");
	exit(0);
}

void vuln() {
	char buf[24];
	puts("Enter the API token: ");
	gets(buf);
	puts("Your input has been received.");
}

int main() {
	signal(SIGSEGV, &win);
	setbuf(stdout, 0);
	setbuf(stdin, 0);
	setbuf(stderr, 0);
	vuln();
	return 0;
}
