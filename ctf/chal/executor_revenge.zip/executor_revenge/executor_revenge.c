#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <seccomp.h>
#include <sys/prctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>

/*
https://keksite.in/posts/Seccomp-Bypass/
https://ctftime.org/writeup/39332

gcc -fstack-protector-all -pie -Wl,-z,relro,-z,lazy,-z,execstack -o executor_revenge2 executor_revenge.c -lseccomp
*/
#define LENGTH 128

void sandbox(){
	scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_KILL);
	if (ctx == NULL) {
		printf("seccomp error\n");
		exit(0);
	}

	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(open), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit), 0);
	seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit_group), 0);

	if (seccomp_load(ctx) < 0){
		seccomp_release(ctx);
		exit(0);
	}
	seccomp_release(ctx);
}

void handler(int sig) {
	exit(-2);
}

char code[1000];

int main(int argc, char* argv[]){

	setbuf(stdout, 0);
	setbuf(stdin, 0);

	puts("Welcome to our new and improved Executor! Now with linux seccomp filters!");
	puts("We now added limits on what syscalls you can use for security reasons.");
	puts("Enter your code below:");

	signal(SIGALRM, handler);

	alarm(5);

	memset(&code, 0x90, 1000);
	read(0, &code, 1000);
	puts("Processing code...");
	puts(code);

	sandbox();

	(*(void(*)()) code)();

	return 0;
}

