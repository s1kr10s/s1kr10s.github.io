#include <stdio.h>
#include <stdlib.h>

void win() {
	system("/bin/cat flag.txt");
	exit(0);
}

void invoice() {
	char num[7];
	puts("Memory safe invoice system: ");
	puts("Enter the length of your first name");
	u_int16_t flength;
	fgets(&num, 7, stdin);
	flength = strtoul(num, NULL, 10); // convierte string a entero sin signo
	
	puts("Enter the length of your last name");
	u_int16_t llength;
	fgets(&num, 7, stdin);
	llength = strtoul(num, NULL, 10); // convierte string a entero sin signo
	
	//integer overflow
	u_int16_t totallength = flength + llength;

	char name[totallength];
	puts("Enter your first name:");
	fgets(&name, flength, stdin);

	puts("Enter your last name:");
	unsigned long bufaddr = &name;
	fgets((bufaddr + flength), llength, stdin);
	puts("Records: No invoice found."); //We'll implement this later
}

int main() {
	setbuf(stdout, 0);
	setbuf(stdin, 0);
	invoice();
}
